export interface BaseEntity {
    id?: string;
    createdOn?: Date;
    modifiedOn?: Date;
}


