module Constants {

    export const BASE_URL = '/api/mcart';
  
}

export default Constants;